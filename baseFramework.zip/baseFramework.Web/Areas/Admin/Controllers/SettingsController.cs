﻿using System.Web.Mvc;

namespace baseFramework.Web.Areas.Admin.Controllers
{
    public class SettingsController : Controller
    {
        // GET: Admin/Settings
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 站点设置
        /// </summary>
        /// <returns></returns>
        public ActionResult SysSetting()
        {
            return View();
        }

        /// <summary>
        /// SEO 设置
        /// </summary>
        /// <returns></returns>
        public ActionResult SEOSetting()
        {
            return View();
        }

        /// <summary>
        /// 邮箱短信
        /// </summary>
        /// <returns></returns>
        public ActionResult MailSMSSetting()
        {
            return View();
        }

        /// <summary>
        /// 支付方式
        /// </summary>
        /// <returns></returns>
        public ActionResult PayWaySetting()
        {
            return View();
        }

        /// <summary>
        /// 权限设置
        /// </summary>
        /// <returns></returns>
        public ActionResult PermissionSetting()
        {
            return View();
        }

        /// <summary>
        /// 快递公司
        /// </summary>
        /// <returns></returns>
        public ActionResult ExpressCopanySetting()
        {
            return View();
        }

        /// <summary>
        /// 地区管理
        /// </summary>
        /// <returns></returns>
        public ActionResult AreaSetting()
        {
            return View();
        }

        /// <summary>
        /// 配送地区
        /// </summary>
        /// <returns></returns>
        public ActionResult ExpressAreaSetting()
        {
            return View();
        }

        /// <summary>
        /// 清理缓存
        /// </summary>
        /// <returns></returns>
        public ActionResult ClearCache()
        {
            return View();
        }

        /// <summary>
        /// 操作日志
        /// </summary>
        /// <returns></returns>
        public ActionResult OperationLog()
        {
            return View();
        }
        
    }
}