﻿using System.Web.Mvc;

namespace baseFramework.Web.Areas.Admin.Controllers
{
    /// <summary>
    /// 会员管理
    /// </summary>
    public class MemberController : Controller
    {
        // GET: Admin/Member
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 会员级别
        /// </summary>
        /// <returns></returns>
        public ActionResult MemberLevel()
        {
            return View();
        }

        /// <summary>
        /// 经验值
        /// </summary>
        /// <returns></returns>
        public ActionResult Exppoints()
        {
            return View();
        }

        /// <summary>
        /// 会员通知
        /// </summary>
        /// <returns></returns>
        public ActionResult Notice()
        {
            return View();
        }

        /// <summary>
        /// 积分管理
        /// </summary>
        /// <returns></returns>
        public ActionResult Points()
        {
            return View();
        }

        /// <summary>
        /// 预存款
        /// </summary>
        /// <returns></returns>
        public ActionResult PreDeposit()
        {
            return View();
        }

        /// <summary>
        /// 会员标签
        /// </summary>
        /// <returns></returns>
        public ActionResult Tags()
        {
            return View();
        }
    }
}