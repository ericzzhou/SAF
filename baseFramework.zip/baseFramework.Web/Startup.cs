﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(baseFramework.Web.Startup))]
namespace baseFramework.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
